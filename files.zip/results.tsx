import React, { useRef, useEffect } from 'react';
import {
  View, Text, StyleSheet, ScrollView,
  TouchableOpacity, Animated, Dimensions
} from 'react-native';
import { useRouter } from 'expo-router';

const { width } = Dimensions.get('window');

const ACTION_CARDS = [
  { priority: 'CRITICAL', title: '120 logon ko evacuate karo', detail: 'Zone A aur B — turant. 3 boats + 8 rescuers deploy karo.', time: '0–1 hr', color: '#E53935', bg: '#1A0A0A' },
  { priority: 'HIGH', title: 'Medical team bhejo', detail: '2 doctors + 4 paramedics. 15 injured reported. Field hospital setup karo.', time: '0–2 hr', color: '#FF6F00', bg: '#1A1200' },
  { priority: 'HIGH', title: 'Supply route establish karo', detail: 'NH-5 blocked. Alternative route via Rampur — helicopter fallback.', time: '1–3 hr', color: '#FF6F00', bg: '#1A1200' },
  { priority: 'MEDIUM', title: 'Communication hub setup karo', detail: 'Satellite phone + radio mesh. 3 towers identified.', time: '2–4 hr', color: '#1565C0', bg: '#0A0F1A' },
  { priority: 'LOW', title: 'Relief camp banao', detail: 'School building — capacity 200 log. Food + water 72hr ke liye.', time: '3–6 hr', color: '#2E7D32', bg: '#0A150A' },
];

const TIMELINE = [
  { time: '0–1 hr', label: 'Rescue & Evacuation', active: true },
  { time: '1–3 hr', label: 'Medical + Logistics', active: false },
  { time: '3–6 hr', label: 'Relief Setup', active: false },
  { time: '6–24 hr', label: 'Recovery Phase', active: false },
];

const RESOURCES = [
  { label: 'Rescuers', value: '8', unit: 'personnel' },
  { label: 'Boats', value: '3', unit: 'units' },
  { label: 'Medical', value: '6', unit: 'personnel' },
  { label: 'Vehicles', value: '4', unit: 'units' },
];

export default function ResultsScreen() {
  const router = useRouter();
  const fadeAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.timing(fadeAnim, { toValue: 1, duration: 500, useNativeDriver: true }).start();
  }, []);

  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      <Animated.View style={{ opacity: fadeAnim }}>

        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity style={styles.backBtn} onPress={() => router.replace('/')}>
            <Text style={styles.backText}>← New Analysis</Text>
          </TouchableOpacity>
          <View style={styles.headerRight}>
            <View style={styles.liveDot} />
            <Text style={styles.liveText}>LIVE PLAN</Text>
          </View>
        </View>

        {/* Situation Summary */}
        <View style={styles.summaryCard}>
          <View style={styles.summaryTop}>
            <Text style={styles.summaryLabel}>SITUATION BRIEF</Text>
            <View style={styles.severityBadge}>
              <Text style={styles.severityText}>SEVERITY: HIGH</Text>
            </View>
          </View>
          <Text style={styles.summaryTitle}>Himachal Pradesh — Flash Flood</Text>
          <Text style={styles.summaryDesc}>120 logon ki jaan khatre mein. 3 villages cut off. Road blocked. Medical support needed.</Text>
          <View style={styles.summaryStats}>
            <View style={styles.summaryStatItem}>
              <Text style={styles.summaryStatNum}>120</Text>
              <Text style={styles.summaryStatLabel}>Affected</Text>
            </View>
            <View style={styles.summaryStatItem}>
              <Text style={styles.summaryStatNum}>15</Text>
              <Text style={styles.summaryStatLabel}>Injured</Text>
            </View>
            <View style={styles.summaryStatItem}>
              <Text style={styles.summaryStatNum}>3</Text>
              <Text style={styles.summaryStatLabel}>Villages</Text>
            </View>
            <View style={styles.summaryStatItem}>
              <Text style={styles.summaryStatNum}>87%</Text>
              <Text style={styles.summaryStatLabel}>Confidence</Text>
            </View>
          </View>
        </View>

        {/* Action Cards */}
        <Text style={styles.sectionTitle}>ACTION PLAN</Text>
        {ACTION_CARDS.map((card, i) => (
          <View key={i} style={[styles.actionCard, { backgroundColor: card.bg, borderLeftColor: card.color }]}>
            <View style={styles.actionTop}>
              <View style={[styles.priorityBadge, { borderColor: card.color }]}>
                <Text style={[styles.priorityText, { color: card.color }]}>{card.priority}</Text>
              </View>
              <Text style={[styles.timeTag, { color: card.color }]}>{card.time}</Text>
            </View>
            <Text style={styles.actionTitle}>{card.title}</Text>
            <Text style={styles.actionDetail}>{card.detail}</Text>
          </View>
        ))}

        {/* Timeline */}
        <Text style={styles.sectionTitle}>TIMELINE</Text>
        <View style={styles.timelineCard}>
          {TIMELINE.map((item, i) => (
            <View key={i} style={styles.timelineRow}>
              <View style={styles.timelineLeft}>
                <View style={[styles.timelineDot, item.active && styles.timelineDotActive]} />
                {i < TIMELINE.length - 1 && <View style={styles.timelineLine} />}
              </View>
              <View style={styles.timelineRight}>
                <Text style={[styles.timelineTime, item.active && styles.timelineTimeActive]}>{item.time}</Text>
                <Text style={styles.timelineLabel}>{item.label}</Text>
              </View>
            </View>
          ))}
        </View>

        {/* Resources */}
        <Text style={styles.sectionTitle}>RESOURCES NEEDED</Text>
        <View style={styles.resourceGrid}>
          {RESOURCES.map((r, i) => (
            <View key={i} style={styles.resourceCard}>
              <Text style={styles.resourceNum}>{r.value}</Text>
              <Text style={styles.resourceLabel}>{r.label}</Text>
              <Text style={styles.resourceUnit}>{r.unit}</Text>
            </View>
          ))}
        </View>

        {/* Replan + Share buttons */}
        <View style={styles.actionRow}>
          <TouchableOpacity style={styles.replanBtn} onPress={() => router.replace('/')}>
            <Text style={styles.replanText}>Update Situation</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.shareBtn}>
            <Text style={styles.shareText}>Share via QR</Text>
          </TouchableOpacity>
        </View>

        {/* Confidence footer */}
        <View style={styles.confidenceBox}>
          <Text style={styles.confidenceText}>AI Confidence: 87% • Based on NDRF historical data</Text>
          <Text style={styles.confirmText}>Human confirmation recommended before execution</Text>
        </View>

        <View style={{ height: 40 }} />

      </Animated.View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0A0E1A' },

  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 20, paddingTop: 56 },
  backBtn: { padding: 8 },
  backText: { color: '#546E8A', fontSize: 13, fontWeight: '600' },
  headerRight: { flexDirection: 'row', alignItems: 'center' },
  liveDot: { width: 8, height: 8, borderRadius: 4, backgroundColor: '#E53935', marginRight: 6 },
  liveText: { fontSize: 11, color: '#E53935', fontWeight: '700', letterSpacing: 2 },

  summaryCard: { margin: 20, marginTop: 4, backgroundColor: '#0F1629', borderRadius: 16, padding: 20, borderWidth: 1, borderColor: '#1A2640' },
  summaryTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  summaryLabel: { fontSize: 11, color: '#546E8A', letterSpacing: 2, fontWeight: '600' },
  severityBadge: { backgroundColor: '#1A0A0A', borderRadius: 6, paddingHorizontal: 10, paddingVertical: 4, borderWidth: 1, borderColor: '#E5393550' },
  severityText: { fontSize: 10, color: '#E53935', fontWeight: '700', letterSpacing: 1 },
  summaryTitle: { fontSize: 17, fontWeight: '800', color: '#FFFFFF', marginBottom: 8 },
  summaryDesc: { fontSize: 13, color: '#546E8A', lineHeight: 20, marginBottom: 16 },
  summaryStats: { flexDirection: 'row', justifyContent: 'space-between' },
  summaryStatItem: { alignItems: 'center' },
  summaryStatNum: { fontSize: 20, fontWeight: '800', color: '#FFFFFF' },
  summaryStatLabel: { fontSize: 11, color: '#546E8A', marginTop: 2 },

  sectionTitle: { fontSize: 11, color: '#546E8A', letterSpacing: 3, fontWeight: '600', marginHorizontal: 20, marginTop: 8, marginBottom: 12 },

  actionCard: { marginHorizontal: 20, marginBottom: 10, borderRadius: 12, padding: 16, borderLeftWidth: 3, borderWidth: 1, borderColor: '#1A2640' },
  actionTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 },
  priorityBadge: { borderRadius: 4, paddingHorizontal: 8, paddingVertical: 3, borderWidth: 1 },
  priorityText: { fontSize: 10, fontWeight: '700', letterSpacing: 1 },
  timeTag: { fontSize: 12, fontWeight: '600' },
  actionTitle: { fontSize: 15, fontWeight: '700', color: '#FFFFFF', marginBottom: 6 },
  actionDetail: { fontSize: 12, color: '#546E8A', lineHeight: 18 },

  timelineCard: { marginHorizontal: 20, backgroundColor: '#0F1629', borderRadius: 14, padding: 20, borderWidth: 1, borderColor: '#1A2640', marginBottom: 8 },
  timelineRow: { flexDirection: 'row', marginBottom: 4 },
  timelineLeft: { alignItems: 'center', marginRight: 16, width: 16 },
  timelineDot: { width: 12, height: 12, borderRadius: 6, backgroundColor: '#1A2640', borderWidth: 1, borderColor: '#2A3A4A' },
  timelineDotActive: { backgroundColor: '#E53935', borderColor: '#E53935' },
  timelineLine: { width: 1, height: 32, backgroundColor: '#1A2640', marginTop: 4 },
  timelineRight: { paddingBottom: 28, flex: 1 },
  timelineTime: { fontSize: 12, color: '#2A3A4A', fontWeight: '600', marginBottom: 2 },
  timelineTimeActive: { color: '#E53935' },
  timelineLabel: { fontSize: 14, color: '#546E8A', fontWeight: '500' },

  resourceGrid: { flexDirection: 'row', flexWrap: 'wrap', marginHorizontal: 14, marginBottom: 8 },
  resourceCard: { width: (width - 52) / 2, backgroundColor: '#0F1629', borderRadius: 12, padding: 16, margin: 6, borderWidth: 1, borderColor: '#1A2640', alignItems: 'center' },
  resourceNum: { fontSize: 28, fontWeight: '800', color: '#FFFFFF', marginBottom: 4 },
  resourceLabel: { fontSize: 13, color: '#FFFFFF', fontWeight: '600', marginBottom: 2 },
  resourceUnit: { fontSize: 11, color: '#546E8A' },

  actionRow: { flexDirection: 'row', marginHorizontal: 20, marginBottom: 16, gap: 10 },
  replanBtn: { flex: 1, backgroundColor: '#0F1629', borderRadius: 12, padding: 14, alignItems: 'center', borderWidth: 1, borderColor: '#1A2640' },
  replanText: { color: '#FFFFFF', fontWeight: '600', fontSize: 13 },
  shareBtn: { flex: 1, backgroundColor: '#E53935', borderRadius: 12, padding: 14, alignItems: 'center' },
  shareText: { color: '#FFFFFF', fontWeight: '700', fontSize: 13 },

  confidenceBox: { marginHorizontal: 20, backgroundColor: '#0D1B0D', borderRadius: 12, padding: 14, borderWidth: 1, borderColor: '#1B5E2040', alignItems: 'center' },
  confidenceText: { fontSize: 12, color: '#4CAF50', fontWeight: '600', marginBottom: 4 },
  confirmText: { fontSize: 11, color: '#546E8A', textAlign: 'center' },
});
