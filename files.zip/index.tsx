import React, { useState, useRef } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet,
  ScrollView, Animated, Alert, Dimensions
} from 'react-native';
import { useRouter } from 'expo-router';
import * as DocumentPicker from 'expo-document-picker';

const { width } = Dimensions.get('window');

export default function HomeScreen() {
  const router = useRouter();
  const [selectedMethod, setSelectedMethod] = useState<string | null>(null);
  const pulseAnim = useRef(new Animated.Value(1)).current;

  React.useEffect(() => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(pulseAnim, { toValue: 1.04, duration: 1500, useNativeDriver: true }),
        Animated.timing(pulseAnim, { toValue: 1, duration: 1500, useNativeDriver: true }),
      ])
    ).start();
  }, []);

  const handlePDF = async () => {
    try {
      const result = await DocumentPicker.getDocumentAsync({ type: 'application/pdf' });
      if (!result.canceled) {
        setSelectedMethod('pdf');
        router.push({ pathname: '/processing', params: { type: 'pdf', name: result.assets[0].name } });
      }
    } catch {
      Alert.alert('Error', 'PDF select nahi ho saka');
    }
  };

  const handleCamera = () => {
    setSelectedMethod('camera');
    router.push({ pathname: '/processing', params: { type: 'camera' } });
  };

  const handleVoice = () => {
    setSelectedMethod('voice');
    router.push({ pathname: '/processing', params: { type: 'voice' } });
  };

  const handleManual = () => {
    router.push({ pathname: '/processing', params: { type: 'manual' } });
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>

      {/* Header */}
      <View style={styles.header}>
        <View style={styles.logoRow}>
          <View style={styles.logoDot} />
          <Text style={styles.logoText}>NEURIX</Text>
          <View style={styles.offlineBadge}>
            <View style={styles.offlineDot} />
            <Text style={styles.offlineText}>OFFLINE</Text>
          </View>
        </View>
        <Text style={styles.tagline}>Disaster Intelligence Engine</Text>
      </View>

      {/* Alert Banner */}
      <Animated.View style={[styles.alertBanner, { transform: [{ scale: pulseAnim }] }]}>
        <View style={styles.alertLeft}>
          <View style={styles.alertIndicator} />
          <Text style={styles.alertTitle}>SYSTEM READY</Text>
        </View>
        <Text style={styles.alertSub}>AI engine loaded • No internet needed</Text>
      </Animated.View>

      {/* Section Title */}
      <Text style={styles.sectionTitle}>INPUT METHOD CHUNEIN</Text>

      {/* Input Cards */}
      <TouchableOpacity style={styles.primaryCard} onPress={handlePDF} activeOpacity={0.85}>
        <View style={styles.cardIconBox}>
          <Text style={styles.cardIconText}>PDF</Text>
        </View>
        <View style={styles.cardBody}>
          <Text style={styles.cardTitle}>PDF Report Upload</Text>
          <Text style={styles.cardDesc}>Disaster report ya sitrep PDF upload karo</Text>
        </View>
        <View style={styles.cardArrow}>
          <Text style={styles.arrowText}>›</Text>
        </View>
      </TouchableOpacity>

      <TouchableOpacity style={styles.primaryCard} onPress={handleCamera} activeOpacity={0.85}>
        <View style={[styles.cardIconBox, { backgroundColor: '#1A2A1A' }]}>
          <Text style={styles.cardIconText}>CAM</Text>
        </View>
        <View style={styles.cardBody}>
          <Text style={styles.cardTitle}>Photo / Camera</Text>
          <Text style={styles.cardDesc}>Document ya field photo scan karo</Text>
        </View>
        <View style={styles.cardArrow}>
          <Text style={styles.arrowText}>›</Text>
        </View>
      </TouchableOpacity>

      <TouchableOpacity style={styles.primaryCard} onPress={handleVoice} activeOpacity={0.85}>
        <View style={[styles.cardIconBox, { backgroundColor: '#1A1A2A' }]}>
          <Text style={styles.cardIconText}>MIC</Text>
        </View>
        <View style={styles.cardBody}>
          <Text style={styles.cardTitle}>Voice Input</Text>
          <Text style={styles.cardDesc}>Bolo — situation verbally describe karo</Text>
        </View>
        <View style={styles.cardArrow}>
          <Text style={styles.arrowText}>›</Text>
        </View>
      </TouchableOpacity>

      {/* Quick Fill */}
      <TouchableOpacity style={styles.secondaryCard} onPress={handleManual} activeOpacity={0.85}>
        <Text style={styles.secondaryCardText}>Quick Form — Manual Input</Text>
        <Text style={styles.secondaryCardSub}>Tap karke fields bharo — fastest method</Text>
      </TouchableOpacity>

      {/* Stats Row */}
      <View style={styles.statsRow}>
        <View style={styles.statBox}>
          <Text style={styles.statNum}>8s</Text>
          <Text style={styles.statLabel}>Avg response</Text>
        </View>
        <View style={styles.statDivider} />
        <View style={styles.statBox}>
          <Text style={styles.statNum}>100%</Text>
          <Text style={styles.statLabel}>Offline</Text>
        </View>
        <View style={styles.statDivider} />
        <View style={styles.statBox}>
          <Text style={styles.statNum}>AI</Text>
          <Text style={styles.statLabel}>Phi-3 Mini</Text>
        </View>
      </View>

      {/* Footer */}
      <Text style={styles.footer}>NEURIX v1.0 • NDRF Field Edition</Text>

    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0A0E1A' },
  content: { padding: 20, paddingTop: 60, paddingBottom: 40 },

  header: { marginBottom: 24 },
  logoRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 6 },
  logoDot: { width: 10, height: 10, borderRadius: 5, backgroundColor: '#E53935', marginRight: 10 },
  logoText: { fontSize: 28, fontWeight: '800', color: '#FFFFFF', letterSpacing: 4, flex: 1 },
  offlineBadge: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#0F2A0F', borderRadius: 20, paddingHorizontal: 10, paddingVertical: 4, borderWidth: 1, borderColor: '#1B5E20' },
  offlineDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: '#4CAF50', marginRight: 5 },
  offlineText: { fontSize: 10, color: '#4CAF50', fontWeight: '700', letterSpacing: 1 },
  tagline: { fontSize: 13, color: '#546E8A', letterSpacing: 2, fontWeight: '500' },

  alertBanner: { backgroundColor: '#0D1B0D', borderRadius: 12, padding: 16, marginBottom: 28, borderWidth: 1, borderColor: '#1B5E20', borderLeftWidth: 3, borderLeftColor: '#4CAF50' },
  alertLeft: { flexDirection: 'row', alignItems: 'center', marginBottom: 4 },
  alertIndicator: { width: 8, height: 8, borderRadius: 4, backgroundColor: '#4CAF50', marginRight: 8 },
  alertTitle: { fontSize: 12, color: '#4CAF50', fontWeight: '700', letterSpacing: 2 },
  alertSub: { fontSize: 12, color: '#546E8A', marginLeft: 16 },

  sectionTitle: { fontSize: 11, color: '#546E8A', letterSpacing: 3, fontWeight: '600', marginBottom: 14 },

  primaryCard: { backgroundColor: '#0F1629', borderRadius: 14, padding: 18, marginBottom: 12, flexDirection: 'row', alignItems: 'center', borderWidth: 1, borderColor: '#1A2640' },
  cardIconBox: { width: 48, height: 48, borderRadius: 10, backgroundColor: '#1A1015', alignItems: 'center', justifyContent: 'center', marginRight: 16, borderWidth: 1, borderColor: '#2A1520' },
  cardIconText: { fontSize: 11, fontWeight: '800', color: '#E53935', letterSpacing: 1 },
  cardBody: { flex: 1 },
  cardTitle: { fontSize: 15, fontWeight: '700', color: '#FFFFFF', marginBottom: 3 },
  cardDesc: { fontSize: 12, color: '#546E8A' },
  cardArrow: { width: 28, height: 28, borderRadius: 14, backgroundColor: '#1A2640', alignItems: 'center', justifyContent: 'center' },
  arrowText: { fontSize: 18, color: '#E53935', fontWeight: '300', marginTop: -2 },

  secondaryCard: { backgroundColor: '#0F1629', borderRadius: 14, padding: 18, marginBottom: 24, borderWidth: 1, borderColor: '#E5393520', borderStyle: 'dashed' },
  secondaryCardText: { fontSize: 14, fontWeight: '600', color: '#E53935', marginBottom: 4 },
  secondaryCardSub: { fontSize: 12, color: '#546E8A' },

  statsRow: { flexDirection: 'row', backgroundColor: '#0F1629', borderRadius: 14, padding: 20, marginBottom: 24, borderWidth: 1, borderColor: '#1A2640', alignItems: 'center', justifyContent: 'space-around' },
  statBox: { alignItems: 'center', flex: 1 },
  statNum: { fontSize: 20, fontWeight: '800', color: '#FFFFFF', marginBottom: 4 },
  statLabel: { fontSize: 11, color: '#546E8A', letterSpacing: 1 },
  statDivider: { width: 1, height: 40, backgroundColor: '#1A2640' },

  footer: { textAlign: 'center', fontSize: 11, color: '#2A3A4A', letterSpacing: 1 },
});
