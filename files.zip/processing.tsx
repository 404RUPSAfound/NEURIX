import React, { useEffect, useRef, useState } from 'react';
import { View, Text, StyleSheet, Animated, Dimensions } from 'react-native';
import { useRouter, useLocalSearchParams } from 'expo-router';

const { width } = Dimensions.get('window');

const STEPS = [
  'Input data extract ho raha hai...',
  'Disaster type identify ho raha hai...',
  'Severity calculate ho rahi hai...',
  'Resource estimation chal rahi hai...',
  'Action plan generate ho raha hai...',
  'Timeline build ho rahi hai...',
];

export default function ProcessingScreen() {
  const router = useRouter();
  const params = useLocalSearchParams();
  const [currentStep, setCurrentStep] = useState(0);
  const [progress, setProgress] = useState(0);
  const progressAnim = useRef(new Animated.Value(0)).current;
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const pulseAnim = useRef(new Animated.Value(0.8)).current;

  useEffect(() => {
    Animated.timing(fadeAnim, { toValue: 1, duration: 600, useNativeDriver: true }).start();
    Animated.loop(
      Animated.sequence([
        Animated.timing(pulseAnim, { toValue: 1.1, duration: 800, useNativeDriver: true }),
        Animated.timing(pulseAnim, { toValue: 0.8, duration: 800, useNativeDriver: true }),
      ])
    ).start();

    let stepIndex = 0;
    const interval = setInterval(() => {
      if (stepIndex < STEPS.length - 1) {
        stepIndex++;
        setCurrentStep(stepIndex);
        const newProgress = ((stepIndex + 1) / STEPS.length) * 100;
        setProgress(Math.round(newProgress));
        Animated.timing(progressAnim, {
          toValue: (stepIndex + 1) / STEPS.length,
          duration: 400,
          useNativeDriver: false,
        }).start();
      } else {
        clearInterval(interval);
        setTimeout(() => {
          router.replace({
            pathname: '/results',
            params: { type: params.type as string }
          });
        }, 800);
      }
    }, 900);

    return () => clearInterval(interval);
  }, []);

  const barWidth = progressAnim.interpolate({
    inputRange: [0, 1],
    outputRange: ['0%', '100%'],
  });

  return (
    <View style={styles.container}>
      <Animated.View style={[styles.content, { opacity: fadeAnim }]}>

        {/* Top label */}
        <Text style={styles.topLabel}>NEURIX AI ENGINE</Text>

        {/* Pulse circle */}
        <View style={styles.circleContainer}>
          <Animated.View style={[styles.outerRing, { transform: [{ scale: pulseAnim }] }]} />
          <Animated.View style={[styles.innerRing, { transform: [{ scale: pulseAnim }] }]} />
          <View style={styles.centerCircle}>
            <Text style={styles.percentText}>{progress}%</Text>
          </View>
        </View>

        {/* Title */}
        <Text style={styles.title}>Analyzing Disaster Data</Text>
        <Text style={styles.subtitle}>AI decision engine chal rahi hai</Text>

        {/* Progress bar */}
        <View style={styles.progressContainer}>
          <View style={styles.progressBar}>
            <Animated.View style={[styles.progressFill, { width: barWidth }]} />
          </View>
        </View>

        {/* Current step */}
        <View style={styles.stepBox}>
          <View style={styles.stepDot} />
          <Text style={styles.stepText}>{STEPS[currentStep]}</Text>
        </View>

        {/* Steps list */}
        <View style={styles.stepsList}>
          {STEPS.map((step, i) => (
            <View key={i} style={styles.stepRow}>
              <View style={[styles.stepBullet, i <= currentStep && styles.stepBulletDone, i === currentStep && styles.stepBulletActive]} />
              <Text style={[styles.stepLabel, i <= currentStep && styles.stepLabelDone]}>{step}</Text>
            </View>
          ))}
        </View>

      </Animated.View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0A0E1A', alignItems: 'center', justifyContent: 'center' },
  content: { width: '100%', alignItems: 'center', padding: 28 },

  topLabel: { fontSize: 11, color: '#E53935', letterSpacing: 4, fontWeight: '700', marginBottom: 36 },

  circleContainer: { width: 140, height: 140, alignItems: 'center', justifyContent: 'center', marginBottom: 32 },
  outerRing: { position: 'absolute', width: 140, height: 140, borderRadius: 70, borderWidth: 1, borderColor: '#E5393530' },
  innerRing: { position: 'absolute', width: 110, height: 110, borderRadius: 55, borderWidth: 1, borderColor: '#E5393560' },
  centerCircle: { width: 80, height: 80, borderRadius: 40, backgroundColor: '#1A0E0F', borderWidth: 2, borderColor: '#E53935', alignItems: 'center', justifyContent: 'center' },
  percentText: { fontSize: 22, fontWeight: '800', color: '#FFFFFF' },

  title: { fontSize: 20, fontWeight: '700', color: '#FFFFFF', marginBottom: 8 },
  subtitle: { fontSize: 13, color: '#546E8A', marginBottom: 28, letterSpacing: 1 },

  progressContainer: { width: '100%', marginBottom: 20 },
  progressBar: { height: 3, backgroundColor: '#1A2640', borderRadius: 2, overflow: 'hidden' },
  progressFill: { height: 3, backgroundColor: '#E53935', borderRadius: 2 },

  stepBox: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#0F1629', borderRadius: 10, padding: 12, marginBottom: 24, width: '100%', borderWidth: 1, borderColor: '#1A2640' },
  stepDot: { width: 8, height: 8, borderRadius: 4, backgroundColor: '#E53935', marginRight: 10 },
  stepText: { fontSize: 13, color: '#90A4AE', flex: 1 },

  stepsList: { width: '100%' },
  stepRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 10 },
  stepBullet: { width: 8, height: 8, borderRadius: 4, backgroundColor: '#1A2640', marginRight: 12, borderWidth: 1, borderColor: '#2A3A4A' },
  stepBulletDone: { backgroundColor: '#1B5E20', borderColor: '#4CAF50' },
  stepBulletActive: { backgroundColor: '#E53935', borderColor: '#E53935' },
  stepLabel: { fontSize: 12, color: '#2A3A4A' },
  stepLabelDone: { color: '#546E8A' },
});
